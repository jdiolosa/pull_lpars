#!/usr/bin/env python

import xmlrpclib
import sys

SATELLITE_URL = (sys.argv[1])
SATELLITE_LOGIN = "batch"
SATELLITE_PASSWORD = "st1ngray"

client = xmlrpclib.Server(SATELLITE_URL, verbose=0)
key = client.auth.login(SATELLITE_LOGIN, SATELLITE_PASSWORD)
list = client.system.listUserSystems(key)

for group in list:
    sysname = group.get('name')
    sysid =  group.get('id')
    print '{0},,,,Satellite,,,{1}' .format (sysname, sysid)


client.auth.logout(key)
